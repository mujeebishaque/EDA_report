from django.shortcuts import render, redirect
from production_app.models import Defect
from django.contrib import messages

# Create your views here.

def index(request):
    return render(request, 'index.html')

def create(request):

    if request.method == 'POST':
    
        defects = Defect()

        defects.customer_name           = request.POST['customer_name']
        defects.order_number            = request.POST['order_number']
        defects.line_number             = request.POST['line_number']
        defects.size                    = request.POST['size']
        defects.dhu                     = request.POST['dhu']
        defects.rft                     = request.POST['rft']
        defects.checked_pieces          = request.POST['checked_pieces']
        defects.article_number          = request.POST['article_number']
        
        jacket                          = request.POST.getlist('jacket')
        trouser                         = request.POST.getlist('trouser')

        if 'on' in jacket:
            defects.jacket = True
        else:
            defects.jacket = False

        if 'on' in trouser:
            defects.trouser = True
        else:
            defects.trouser = False

        # ------------------------------------------------------- CRITICAL DEFECTS MODEL DEFINITION STARTS HERE # 6 ------------------------------------------>
         
        defects.critical_defect_desc_1         = request.POST.getlist('critical_defect_1')
        defects.critical_defect_type_1         = request.POST['critical_defect_type_1']
        defects.critical_number_of_defects_1   = request.POST['critical_number_of_defects_1']

        defects.critical_defect_desc_2         = request.POST.getlist('critical_defect_2')
        defects.critical_defect_type_2         = request.POST['critical_defect_type_2']
        defects.critical_number_of_defects_2   = request.POST['critical_number_of_defects_2']

        defects.critical_defect_desc_3         = request.POST.getlist('critical_defect_3')
        defects.critical_defect_type_3         = request.POST['critical_defect_type_3']
        defects.critical_number_of_defects_3   = request.POST['critical_number_of_defects_3']

        defects.critical_defect_desc_4         = request.POST.getlist('critical_defect_4')
        defects.critical_defect_type_4         = request.POST['critical_defect_type_4']
        defects.critical_number_of_defects_4   = request.POST['critical_number_of_defects_4']

        defects.critical_defect_desc_5         = request.POST.getlist('critical_defect_5')
        defects.critical_defect_type_5         = request.POST['critical_defect_type_5']
        defects.critical_number_of_defects_5   = request.POST['critical_number_of_defects_5']

        defects.critical_defect_desc_6         = request.POST.getlist('critical_defect_6')
        defects.critical_defect_type_6         = request.POST['critical_defect_type_6']
        defects.critical_number_of_defects_6   = request.POST['critical_number_of_defects_6']
        
        # -------------------------------------------------------- CRITICAL MODEL DEFINITION ENDS HERE ----------------------------------------------------->

        # -------------------------------------------------------- MAJOR DEFECTS DEFINITION  STARTS HERE # 14 ---------------------------------------------------> 

        defects.major_defect_desc_1            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_1            = request.POST['major_defect_type_1']
        defects.major_number_of_defects_1      = request.POST['major_number_of_defects_1']

        defects.major_defect_desc_2            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_2            = request.POST['major_defect_type_2']
        defects.major_number_of_defects_2      = request.POST['major_number_of_defects_2']

        defects.major_defect_desc_3            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_3            = request.POST['major_defect_type_3']
        defects.major_number_of_defects_3      = request.POST['major_number_of_defects_3']

        defects.major_defect_desc_4            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_4            = request.POST['major_defect_type_4']
        defects.major_number_of_defects_4      = request.POST['major_number_of_defects_4']

        defects.major_defect_desc_5            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_5            = request.POST['major_defect_type_5']
        defects.major_number_of_defects_5      = request.POST['major_number_of_defects_5']

        defects.major_defect_desc_6            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_6            = request.POST['major_defect_type_6']
        defects.major_number_of_defects_6      = request.POST['major_number_of_defects_6']

        defects.major_defect_desc_7            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_7            = request.POST['major_defect_type_7']
        defects.major_number_of_defects_7      = request.POST['major_number_of_defects_7']

        defects.major_defect_desc_8            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_8            = request.POST['major_defect_type_8']
        defects.major_number_of_defects_8      = request.POST['major_number_of_defects_8']

        defects.major_defect_desc_9            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_9            = request.POST['major_defect_type_9']
        defects.major_number_of_defects_9      = request.POST['major_number_of_defects_9']

        defects.major_defect_desc_10            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_10            = request.POST['major_defect_type_10']
        defects.major_number_of_defects_10      = request.POST['major_number_of_defects_10']

        defects.major_defect_desc_11            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_11            = request.POST['major_defect_type_11']
        defects.major_number_of_defects_11      = request.POST['major_number_of_defects_11']

        defects.major_defect_desc_12            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_12            = request.POST['major_defect_type_12']
        defects.major_number_of_defects_12      = request.POST['major_number_of_defects_12']

        defects.major_defect_desc_13            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_13            = request.POST['major_defect_type_13']
        defects.major_number_of_defects_13      = request.POST['major_number_of_defects_13']

        defects.major_defect_desc_14            = request.POST.getlist('major_defect_1')
        defects.major_defect_type_14            = request.POST['major_defect_type_14']
        defects.major_number_of_defects_14      = request.POST['major_number_of_defects_14']

        # ------------------------------------------------------- MINOR DEFECTS DEFINITION STARTS HERE ----------------------------------------------------->

        defects.minor_defect_desc          = request.POST.getlist('dust_stain')
        defects.minor_defect_type          = request.POST['dust_stain_desc']
        defects.minor_number_of_defects    = request.POST['number_of_dust_stains']

        # ------------------------------------------------------ MINOR DEFECTS DEFINITION ENDS HERE -------------------------------------------------------->

        defects.save()
        # print(customer_name, order_number, line_number, size, dhu, rft, checked_pieces, article_number)
        messages.error(request, 'Information Successfully Saved!')
        print(request.POST)
        return render(request, 'index.html', {'success': 'Data Saved Succesfully!'})