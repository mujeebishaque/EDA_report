from django.apps import AppConfig


class ProductionAppConfig(AppConfig):
    name = 'production_app'
