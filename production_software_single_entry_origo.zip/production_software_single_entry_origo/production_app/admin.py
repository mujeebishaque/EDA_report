from django.contrib import admin
from production_app.models import Defect
# Register your models here.


class DefectAdmin(admin.ModelAdmin):
    list_display = ['customer_name', 'order_number', 'line_number', 'size', 'dhu', 'rft', 'checked_pieces', 'article_number']
    list_filter = ['customer_name', 'order_number', 'line_number', 'article_number', 'datestamp']

admin.site.register(Defect, DefectAdmin)