from django.db import models


class Defect(models.Model):
    
    customer_name = models.CharField("Customer Name", max_length=64, null=False)
    order_number  = models.CharField("Order No", max_length=64, null=False)
    line_number   = models.CharField("Line No", max_length=32, null=False)
    size          = models.CharField("Size", max_length=64, null=False)
    dhu           = models.IntegerField("DHU", null=False)
    rft           = models.IntegerField("RFT", null=False)

    dhu_percentage   = models.CharField("DHU %", max_length=128, blank=True)
    rft_percentage   = models.CharField("RFT %", max_length=128, blank=True)

    checked_pieces = models.IntegerField("Checked Pieces", blank=False)

    article_number = models.CharField("Article Number", max_length=32, blank=False)
    trouser        = models.BooleanField(default=False)
    jacket         = models.BooleanField(default=False)
    
    # total critical defects are 6

    critical_defect_desc_1       = models.CharField("Critical Defect Desc.", max_length=128)
    critical_defect_type_1       = models.CharField("Critical Defect Type", max_length=128)
    critical_number_of_defects_1 = models.PositiveIntegerField("Critical No. Of Defects", blank=True)

    critical_defect_desc_2       = models.CharField("Critical Defect Desc.", max_length=128)
    critical_defect_type_2       = models.CharField("Critical Defect Type", max_length=128)
    critical_number_of_defects_2 = models.PositiveIntegerField("Critical No. Of Defects", blank=True)
    
    critical_defect_desc_3       = models.CharField("Critical Defect Desc.", max_length=128)
    critical_defect_type_3       = models.CharField("Critical Defect Type", max_length=128)
    critical_number_of_defects_3 = models.PositiveIntegerField("Critical No. Of Defects", blank=True)
    
    critical_defect_desc_4       = models.CharField("Critical Defect Desc.", max_length=128)
    critical_defect_type_4       = models.CharField("Critical Defect Type", max_length=128)
    critical_number_of_defects_4 = models.PositiveIntegerField("Critical No. Of Defects", blank=True)
    
    critical_defect_desc_5       = models.CharField("Critical Defect Desc.", max_length=128)
    critical_defect_type_5       = models.CharField("Critical Defect Type", max_length=128)
    critical_number_of_defects_5 = models.PositiveIntegerField("Critical No. Of Defects", blank=True)
    
    critical_defect_desc_6       = models.CharField("Critical Defect Desc.", max_length=128)
    critical_defect_type_6       = models.CharField("Critical Defect Type", max_length=128)
    critical_number_of_defects_6 = models.PositiveIntegerField("Critical No. Of Defects", blank=True)
    
    # -------------------------------------- CRITICAL DEFECT MODEL ENDS HERE ----------------------------------------

    # total major defects are 14

    major_defect_desc_1       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_1       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_1 = models.PositiveIntegerField("Major No. Of Defects")
    
    major_defect_desc_2       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_2       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_2 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_3       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_3       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_3 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_4       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_4       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_4 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_5       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_5       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_5 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_6       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_6       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_6 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_7       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_7       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_7 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_8       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_8       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_8 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_9       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_9       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_9 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_10       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_10       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_10 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_11       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_11       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_11 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_12       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_12       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_12 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_13       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_13       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_13 = models.PositiveIntegerField("Major No. Of Defects")

    major_defect_desc_14       = models.CharField("Major Defect Desc.", max_length=128)
    major_defect_type_14       = models.CharField("Major Defect Type", max_length=128)
    major_number_of_defects_14 = models.PositiveIntegerField("Major No. Of Defects")

    # -------------------------------------- MINOR DEFECT -----------------------------------------------------------

    minor_defect_desc       = models.CharField("Minor Defect Desc.", max_length=128)
    minor_defect_type       = models.CharField("Minor Defect Type", max_length=128)
    minor_number_of_defects = models.PositiveIntegerField("Minor No. Of Defects")

    datestamp               = models.DateField(auto_now_add=True)
    timestamp               = models.TimeField(auto_now_add=True)
    datetime_stamp          = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.customer_name